AUTO Commit and Auto Push To Github

How To Run ?
1. Create a personal Access Token of your github account (https://docs.github.com/en/github/authenticating-to-github/keeping-your-account-and-data-secure/creating-a-personal-access-token) [minimum : repo permission]
2. Open config.php
3. Fill $username = your github username
4. FIll $token with your personal access token
5. php run.php
6. wait until the program end

