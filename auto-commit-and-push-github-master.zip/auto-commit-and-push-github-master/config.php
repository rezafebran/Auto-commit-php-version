<?php
$username = "setorantimothy";
$token = "youraccesstoken";

?>